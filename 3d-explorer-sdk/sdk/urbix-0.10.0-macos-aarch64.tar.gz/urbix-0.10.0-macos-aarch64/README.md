# Urbix

A platform-agnostic and language-agnostic modular engine for generating an
explorable, infinite procedural city that can be used/called from other engines
either via CLI or API.

This is a Rust crate (library) that deterministically generates an unbounded
city in **chunks on demand**. It exposes its core data types through a C FFI
surface, so renderers, game engines, or other tools in any language can consume
the generated city without depending on Rust.

## Objectives

The full design lives in [`Urbix_Project.md`](Urbix_Project.md); in short:

- **A convincing, varied skyline.** Distinct urban regions — skyscraper business
  districts, tranquil residential areas, busy commercial zones, dirty industrial
  zones, and green parks — each with its own density, building-height
  distribution, and color scheme.
- **Infinite world, deterministic generation.** The city is generated per-chunk
  on demand, so it is effectively unbounded while remaining reproducible from a
  seed.
- **High-performance, bounded memory.** Chunks are LRU-cached and evicted once
  they fall beyond the current draw distance, so infinite generation never
  grows unbounded in RAM.
- **Extensible and modular.** A clean module boundary (hashing, zones, regions,
  streets, buildings, caching, engine) lets capabilities be changed or expanded
  independently.
- **Truly engine-agnostic.** Urbix only *generates* the city; rendering, UI,
  gameplay, and everything else is left to the consuming software.

## Status

Tracked milestone-by-milestone in `Urbix_Project.md` §7 (✅ done / 🔨 in
progress / ⬜ pending). Current version: `0.9.0` (see `CHANGELOG.md`).

| Milestone | Status |
|---|---|
| M1 — Data layer & hashing | ✅ Done (0.2.0) |
| M2 — Voronoi region layer | ✅ Done |
| M3 — Chunk generation core loop (streets + buildings) | ✅ Done (0.3.0) |
| M4 — Cache & engine facade | ✅ Done (0.4.0) |
| M5 — FFI & binary wire format | ✅ Done (0.5.0, audit 0.5.1) |
| M6 — Interior hooks | ✅ Done (0.6.0) |
| M7 — CLI, docs & benchmarks | ✅ Done (0.7.0) |
| M8 — Modular customization | ✅ Done (0.8.0) |
| M9 — Interior layout generation | ✅ Done (0.9.0) |
| M10 — Interior FFI export | ✅ Done (0.10.0) |

M9 completes data-driven interior layout generation: each built lot gets an
`InteriorContext` (zone, blended affinity, footprint, height→floor derivation,
palette, street-facing entrance side, seed) that interiors react to, and a
per-zone `Blueprint` rule table (room templates, weights, min/max sizes —
`#[repr(C)]`, tunable via `WorldConfig`) drives the layout. The generator
exposes `InteriorState::generate(id, ctx)` against a tile-grid mini-world
(`layout.rs`: `Tile`/`Floor`/`InteriorLayout`): per storey it seals a wall
ring, places the circulation core and a street-facing `Door` (the edge the lot
faces is picked to match the street it abuts), rolls rooms from the blueprint
weighted tables, greedily places each within a navigable margin, then fills
leftover cells as `Corridor` and punches a `Door` at every room's opening. See
[`docs/interiors.md`](docs/interiors.md) for the full algorithm.

M10 ships that interior out the C border: `urbix_generate_interior(engine, wx,
wz)` returns a `UrbixInterior` flat buffer (per-storey `Tile` grids + room-kind
tags keyed by world coordinates, following the Rust generator path exactly), so
a renderer that streams chunks can also render room layouts with no Rust.
Release it with `urbix_interior_free`.

Each chunk is produced by: querying the continuous Voronoi zone field at the
cell's absolute world coordinates → resolving blended zone parameters → laying
out the street grid → placing buildings (height, facade palette, interior key),
then packing the results into flat `#[repr(C)]` cell records.

## Design choices

- **Deterministic from a seed.** Everything derives from a seeded hash
  `hash(x, y, seed, domain) -> u64`. There is no global RNG and no cross-chunk
  write dependency, so the same seed always reproduces the same city, and
  adjacent chunks agree at their shared edges.
- **Fuzzy Voronoi districts.** A fixed set of seed-derived Voronoi sites
  (24–48) are mapped to the five zone types and queried *continuously* for zone
  affinity, rather than stored as a per-chunk static map — giving soft, blended
  borders between districts.
- **Wide (i64) world coordinates.** Per-cell generation and hashing operate on
  `i64` so an effectively infinite city never overflows the old `i32` range.
  Coordinates within `i32` produce byte-identical output to earlier versions.
- **FFI-first / language-agnostic.** All public data types are `#[repr(C)]`
  and match a fixed on-wire layout (`Cell` = 40 B, header = 32 B). The C header
  (`include/urbix.h`) is auto-generated from `src/ffi.rs` via `cbindgen` in
  `build.rs` (checked in, best-effort so offline builds keep working), and the
  crate emits both `staticlib` (`liburbix.a`) and `cdylib` for C consumers.
  `urbix_generate_chunk` transfers buffer ownership to the caller (must be freed
  only via `urbix_chunk_free`); since M10, `urbix_generate_interior(engine, wx,
  wz)` hands over a building's room layout the same way (freed via
  `urbix_interior_free`). The engine handle is opaque. Compat shims
  `URBIX_FLAG_STREET`/`URBIX_FLAG_PARK` are preserved.
- **Bounded memory.** `ChunkCache` keeps chunks keyed by `ChunkId` and evicts
  by Chebyshev distance from the current center, with an optional hard capacity.
- **Modular customization.** All artist-tunable data (per-zone `ZoneParams`,
  `ZONE_WEIGHTS`, Voronoi `span`/`power`/`epsilon`, `zone_hues`, interior
  `width/height` ranges) live in `WorldConfig` and can be loaded from
  `TOML`/`JSON` (`urbix.toml.example` / `urbix.json.example`) via
  `WorldConfig::from_file` or `urbix --config`; CLI flags override file.
  `WorldConfig::default()` is byte-identical to pre-8.0 hardcoded values.
  Since M9, this extends to interiors: `WorldConfig` carries a per-zone
  `Blueprint` table (fixed-size `#[repr(C)]`, serde-tuned room templates —
  `interior_floor_height`, `interior_max_floors`, `interior_blueprints`).
- **Lean dependencies.** Core generation is `hash` + `zones` + `region` with no
  heavy deps; `clap`/`serde`/`toml` power the CLI/file-input, `criterion`/`image`
  are dev-only (benchmarks/visualizer).

## Visualizer

A small example tool renders a generated region to an image so the engine's
output can be inspected by eye:

```sh
cargo run --release --example viz -- \
  --seed 445566 --center-cx 0 --center-cy 0 --extent 8 --chunk-size 32 --out out.png
```

It paints one pixel per cell and supports two colouring modes: `hybrid`
(per-district zone hue, brightened by building height, roads drawn as streets)
and `affinity` (flat dominant-zone colour). It writes both a dependency-free
P6 PPM (`.ppm`) and a PNG (`.png`). Run with `--help` for the full flag list.

## Installation

**Rust (crates.io):**
```sh
cargo add urbix@0.8
```
Docs at `docs.rs/urbix`, `WorldEngine` in Rust, `include/urbix.h` for C.

**C — prebuilt tarballs (C-first, recommended):**
Each GitHub Release (`v*`) publishes `urbix-<ver>-<target>.tar.gz/.zip` for
`linux-x86_64`, `macos-aarch64`, `windows-x86_64` (see `release.yml`). Each
contains `include/urbix.h`, `lib/liburbix.{a,so,dylib}` / `lib/urbix.lib` +
`bin/urbix.dll`, `LICENSE`, `README.md`:
```sh
curl -L https://github.com/drax-xard/Urbix/releases/download/v0.8.0/urbix-0.8.0-linux-x86_64.tar.gz | tar xz
cc -I urbix-0.8.0-linux-x86_64/include -c examples/basic_usage.c -o /tmp/basic_usage.o
cc /tmp/basic_usage.o -L urbix-0.8.0-linux-x86_64/lib -lurbix -ldl -lm -pthread -o /tmp/basic_usage && /tmp/basic_usage
# pkg-config (after make install or PKG_CONFIG_PATH)
pkg-config --cflags --libs urbix
# CMake
cmake -S . -B build -DCMAKE_PREFIX_PATH=/tmp/install && cmake --build build
# find_package(urbix CONFIG) → target urbix::urbix
```

**From source:**
```sh
cargo build --release  # also regenerates include/urbix.h via build.rs (cbindgen)
cc -I include -c examples/basic_usage.c -o /tmp/basic_usage.o
cc /tmp/basic_usage.o -L target/release -lurbix -ldl -lm -pthread -o /tmp/basic_usage  # Linux; macOS add -framework Security -framework CoreFoundation
```

## Usage

The library is in early development (currently `0.9.0`); the public surface is
`WorldEngine` in Rust and the C ABI in `include/urbix.h` (see
`Urbix_Project.md` §2.3-2.4 for the wire format):

```c
#include "urbix.h"
UrbixEngine *e = urbix_engine_create(445566);
UrbixChunkBuffer buf = urbix_generate_chunk(e, 0, 0);
// buf.data is ChunkHeader (32 B) + cell_count * UrbixCell (40 B)
urbix_chunk_free(buf);
urbix_engine_destroy(e);
```

`examples/basic_usage.c` is the minimal C consumer. `examples/viz.rs` is the
visualizer below.

### CLI

```sh
# single chunk, binary wire format (defaults from WorldConfig)
cargo run -- --seed 445566 --cx 0 --cy 0 --format bin --out chunk_0_0.bin
# via file + CLI override (text file or runtime params)
cargo run -- --config urbix.toml.example --seed 7 --cx 0 --cy 0 --radius 2 --format json --out ./out
# JSON alternative
cargo run -- --config urbix.json.example --cx 1 --cy 2 --chunk-size 8 --format bin
cargo run -- --help
```

Flags: `--config <path>` (TOML or JSON, sniffed by extension), `--seed` (u64),
`--cx/--cy` (i32), `--radius` (u32, 0=single, max 64), `--chunk-size` (u16, 1..=256),
`--draw-distance`/`--voronoi-site-count` overrides, `--format bin|json` (default `bin`),
`--out` (file for single, dir for grid). File values are base, CLI flags override.
Binary output is exactly `ChunkBuffer::as_bytes()` (header + cells) and can be
read with `ChunkHeader`/`Cell` or via the FFI header. Example files:
`urbix.toml.example` / `urbix.json.example`.

For deep dives see `docs/world_generation.md` (Voronoi/ chunk pipeline),
`docs/api.md` (C ABI + memory contract), and `docs/interiors.md` (interior
generation & blueprint tables).

## Verification

```sh
cargo build --all-targets
cargo test
cargo clippy --all-targets
cargo fmt --check
cargo bench --bench chunk_gen  # criterion: single chunk, 100-sweep, cache hit/miss
```

Note: Rust here is installed via rustup but not on the default `PATH`; source it
with `. "$HOME/.cargo/env"` first in a fresh shell.
